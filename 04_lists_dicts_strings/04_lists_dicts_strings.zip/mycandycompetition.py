#!/usr/bin/python

def index(list, element):
  return None

def count(list, element):
  return None

def swap(string, a, b):
  return None

def peterpan(string):
  return None

def growl(string):
  return None

def overdose(string, a):
  return None

def dontgo(string, a, b):
  return None

def isPrime(n):
  return None

def primes(n):
  return None

def factor(n):
  return None

def place(n, x):
  return None

def sort(list):
  return None
